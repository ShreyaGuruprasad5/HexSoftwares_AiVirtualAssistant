import speech_recognition as aa
import pyttsx3
import pywhatkit
import datetime
import wikipedia
import time
import requests


listener = aa.Recognizer()
listener.energy_threshold = 300
listener.pause_threshold = 0.6
reminders = []  


def talk(text):
    """Speaks text aloud and prints it."""
    print(f"🗣️ Aura: {text}")
    engine = pyttsx3.init()  
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[0].id)
    engine.setProperty('rate', 175)
    engine.say(text)
    engine.runAndWait()
    engine.stop()


def input_instruction():
    """Listen for microphone input and return recognized text."""
    try:
        with aa.Microphone() as origin:
            print("🎧 Listening...")
            listener.adjust_for_ambient_noise(origin, duration=1)
            speech = listener.listen(origin, timeout=5, phrase_time_limit=7)
            instruction = listener.recognize_google(speech)
            instruction = instruction.lower()
            if "aura" in instruction:
                instruction = instruction.replace("aura", "").strip()
            print(f"👉 You said: {instruction}")
            return instruction
    except aa.UnknownValueError:
        print("❌ Didn't catch that.")
        return ""
    except aa.RequestError:
        talk("Network error. Please check your connection.")
        return ""
    except Exception as e:
        print("⚠️ Error:", e)
        return ""


def get_weather(city="your city"):
    try:
        res = requests.get("https://wttr.in/?format=3", timeout=5)
        if res.status_code == 200:
            return res.text
        else:
            return "Sorry, I couldn’t get the weather information right now."
    except:
        return "Unable to fetch weather details at the moment."

def set_alarm(alarm_time):
    talk(f"Alarm set for {alarm_time}")
    while True:
        current_time = datetime.datetime.now().strftime("%H:%M")
        if current_time == alarm_time:
            talk("⏰ Wake up bro! It's time!")
            break
        time.sleep(30)

def add_reminder(text):
    reminders.append(text)
    talk("Got it! I’ve added the reminder: " + text)


def show_reminders():
    if reminders:
        talk("Here are your reminders:")
        for r in reminders:
            talk(r)
    else:
        talk("You have no reminders right now.")

def play_aura():
    talk("Hello bro! Aura is now active and ready to go.")
    while True:
        instruction = input_instruction()

        if instruction == "":
            continue

        if "play" in instruction:
            song = instruction.replace("play", "")
            talk("Playing " + song)
            pywhatkit.playonyt(song)

        elif "time" in instruction:
            time_now = datetime.datetime.now().strftime("%I:%M %p")
            talk("Current time is " + time_now)

        elif "date" in instruction:
            date_today = datetime.datetime.now().strftime("%d %B %Y")
            talk("Today's date is " + date_today)

        elif "how are you" in instruction:
            talk("I’m awesome, how about you?")

        elif "what is your name" in instruction:
            talk("I am Aura, your virtual assistant.")

        elif "who is" in instruction:
            human = instruction.replace("who is", "")
            try:
                info = wikipedia.summary(human, 1)
                print(info)
                talk(info)
            except:
                talk("Sorry, I couldn’t find any information on that.")

        elif "set alarm" in instruction:
            talk("Sure, tell me the time for the alarm in 24-hour format like 06:30")
            alarm_time = input_instruction()
            set_alarm(alarm_time)

        elif "add reminder" in instruction:
            talk("Alright, what should I remind you about?")
            reminder_text = input_instruction()
            add_reminder(reminder_text)

        elif "show reminders" in instruction or "what are my reminders" in instruction:
            show_reminders()

        elif "weather" in instruction:
            weather_info = get_weather()
            talk(weather_info)

        elif "stop" in instruction or "exit" in instruction or "quit" in instruction:
            talk("Alright bro, shutting down. Take care!")
            break

        else:
            talk("Please repeat that, I didn’t catch it.")

play_aura()